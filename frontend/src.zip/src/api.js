// Small wrapper around fetch for the Flask API.
//
// Security notes (SR-16):
// - The session lives in an HttpOnly cookie that JavaScript can't read.
//   Nothing sensitive goes into localStorage or sessionStorage.
// - The CSRF token is kept in memory only and sent in the X-CSRF-Token
//   header on every request that changes something.

let csrfToken = null

export class ApiError extends Error {
  constructor(status, message) {
    super(message)
    this.status = status
  }
}

async function refreshCsrf() {
  const r = await fetch('/api/auth/csrf', { credentials: 'same-origin' })
  csrfToken = (await r.json()).csrf_token
}

export async function api(path, { method = 'GET', body } = {}) {
  const unsafe = method !== 'GET'
  if (unsafe && !csrfToken) await refreshCsrf()
  const headers = {}
  if (body !== undefined) headers['Content-Type'] = 'application/json'
  if (unsafe) headers['X-CSRF-Token'] = csrfToken

  const r = await fetch(path, {
    method,
    credentials: 'same-origin',
    headers,
    body: body === undefined ? undefined : JSON.stringify(body),
  })
  const data = await r.json().catch(() => ({}))
  if (!r.ok) throw new ApiError(r.status, data.message || data.error || 'Request failed')
  return data
}

export async function login(email, password) {
  await refreshCsrf()
  const data = await api('/api/auth/login', { method: 'POST', body: { email, password } })
  csrfToken = data.csrf_token // server issues a new session on login
  return data // { role } or { mfa_required } or { mfa_setup_required }
}

// SR-01: second step for staff accounts. The server issues a fresh session
// (and CSRF token) once the code is accepted.
export async function mfaSetup() {
  return api('/api/auth/mfa/setup', { method: 'POST' })
}

export async function mfaVerify(code) {
  const data = await api('/api/auth/mfa/verify', { method: 'POST', body: { code } })
  csrfToken = data.csrf_token
  return data
}

export async function logout() {
  await api('/api/auth/logout', { method: 'POST' })
  csrfToken = null
}

export const getMe = () => api('/api/auth/me')
